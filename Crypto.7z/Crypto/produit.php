<?php
include('header.php');?>


	
  <section class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="content">
            <h1 class="page-name">Descriptif</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
				<li class="breadcrumb-item"><a href="shop.php">Boutique</a></li>
                <li class="breadcrumb-item active" aria-current="page">Cryptomonnaies</li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  

<?php
	//on se connecte
	connectMaBase();
    //requête SQL
	$sql='SELECT * FROM coin';
	$req=mysql_query($sql) or die('ERREUR SQL ! <br>'.$sql.'<br>'.mysql_error());
	//boucle qui va parcourir toutes les lignes
	//de la requete et construire un tableau
	//en html
	echo "<table  border>
			<tr>
				<th>Nom de la monnaie</th>
				<th> Symbobole</th>
				<th> Stock </th>
				<th> Prix à	l'unité</th>
				<th>Cours de la monnaie dans les dernières 24h</th>
		</tr>";
	while ($data=mysql_fetch_array($req)) {
		echo '<tr><td>'.$data['nomcoin'].'</td>
			<td>'.$data['symbolecoin'].'</td>
			<td>'.$data['quantitecoin'].'</td> 
			<td>'.$data['prixcoin'].'$
			<td>'.$data['evolutioncoin'].'%</tr>';
				}
		echo '</table>';
	mysql_free_result($req); //on libère mysql
	//de la requête
	mysql_close(); //on ferme
	
	include('footer.php');
?>	
