<?php
include("fonctions.php");
?> 


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Traphouse : Boutique</title>
	<link rel="stylesheet" href="css/style.css.css">
<!-- basic -->
    <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/logo.jpg" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!-- owl stylesheets --> 
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesheet" href="css/owl.theme.default.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->	
</head>
<html lang="fr">
<body style="background-color:#AFEEEE;">
	
  <section class="top-header">
	 <div class="container">
      <div class="row">
        <div class="col-md-4 col-xs-12 col-sm-4">
          <div class="contact-number">
            <i class="fa fa-phone"></i>
            <span>09 82 73 22 33</span>
          </div>
        </div>     
          <!-- Site Logo -->
          <div class="logo">
            <a href="index.php"><img src="images/logo3.png" alt="#"></a>
          </div>
        </div>
		
		<div class="col-md-4 col-xs-12 col-sm-4">
          <ul class="top-menu list-inline">
            <li class="list-inline-item"><a href="cart.html"><i class="fa fa-shopping-cart"></i>Panier</a></li>
            <li class="list-inline-item"><a href="login.html"><i class="fa fa-sign-in"></i>Se connecter</a></li>
          </ul>
        </div>
      </div>
    </div>


	</section>
	  <section class="menu">
    <div class="container">
      <nav class="navbar navbar-expand-lg navbar-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Accueil</a> 
            </li>
            <li class="nav-item active dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Boutique<span class="sr-only">(current)</span>
              </a>
              <div class="dropdown-menu full-width" aria-labelledby="navbarDropdown">
                <div class="row">
                  <div class="col-4">
                    <div class="dropdown-header">Cryptomonnaies</div>
                    <div class="dropdown-divider"></div>
                    <a href="shop.php">Botcoin</a>
                    <a href="shop.php">Tornado</a>
                    <a href="shop.php">Maki<a>
                    <a href="shop.php">Voir la liste</a>
                    <a href="shop.php"></a>
                  </div>
                  <div class="col-4">
                    <div class="dropdown-header">Outils</div>
                    <div class="dropdown-divider"></div>
                    <a href="shop.php">Cours des monnaies</a>
                    <a href="shop.php">Prédictions</a>
                    <a href="shop.php"></a>
                    <a href="shop.php"></a>
                    <a href="shop.php"></a>
                  </div>
                </div>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Renseignements
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="about.php">À propos de nous</a>
                <a class="dropdown-item" href="#">Contact</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </section>

  <section class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="content">
            <h1 class="page-name">Boutique</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active" aria-current="page">Cryptomonnaies</li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="products section">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="widget">
            <h4 class="widget-title">Classer par</h4>
          </div>

          <div id="accordion">
            <div class="card">
              <div class="card-header" id="headingOne">
                <h5>
                  <a href="" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    Cryptomonnaies
                  </a>
                </h5>
              </div>

              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                  <ul class="list-unstyled">
                    <li><a href="">Botcoin</a></li>
                    <li><a href="">Tornado</a></li>
                    <li><a href="">Sushi</a></li>
					<li><a href="">Autres altcoins</a></li>
                  </ul>
                </div>
              </div>
            </div>

            <div class="card">
              <div class="card-header" id="headingOne">
                <h5>
                  <a href="" class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    Portefeuillle
                  </a>
                </h5>
              </div>

              <div id="collapseTwo" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                  <ul class="list-unstyled">
                    <li><a href="">Clé USB</a></li>
                    <li><a href="">Coinbase</a></li>
                    <li><a href="">Breadwallet</a></li>
                  </ul>
                </div>
              </div>
            </div>

            <div class="card">
              <div class="card-header" id="headingOne">
                <h5>
                  <a href="" class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                    Pants
                  </a>
                </h5>
              </div>

              <div id="collapseThree" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                  <ul class="list-unstyled">
                    <li><a href="">Dress</a></li>
                    <li><a href="">Pleated</a></li>
                    <li><a href="">Cargo</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-9">
          <div class="row">
            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <span class="bage">Nouveauté</span>
                  <img class="img-responsive" src="images/magi.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Magi </a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/botcoin.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Botcoin</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/tornado.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Tornado</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/venom.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Venom</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <span class="bage">Nouveauté</span>
                  <img class="img-responsive" src="images/plural.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Plural</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/gury.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Gury</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/harch.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Harch</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/maki.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Maki</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>


            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/girco.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-single.html">Girco</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/cista.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="product-single.html"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href=""><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
			
                <div class="product-content">
                  <h4><a href="product-single.html">Cista</a></h4>
                  <p class="price">$200</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer class="footer section text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <ul class="social-media">
            <li>
              <a href="">
                <i class="fa fa-instagram"></i>
              </a>
            </li>
            <li>
              <a href="">
                <i class="fa fa-twitter"></i>
              </a>
            </li>
            <li>
              <a href="">
                <i class="fa fa-pinterest"></i>
              </a>
            </li>
          </ul>
          <ul class="footer-menu">
            <li>
              <a href="">Contact</a>
            </li>
            <li>
              <a href="">Livraison</a>
            </li>
            <li>
              <a href="">Mentions légales</a>
            </li>
            <li>
              <a href="">Protection des données personnelles</a>
            </li>
          </ul>
          <p class="copyright-text">Copyright © 2021 All Rights Reserved. Traphouse </p>
        </div>
      </div>
    </div>
  </footer>

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="script.js"></script>
</body>
</html>