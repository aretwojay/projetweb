<!DOCTYPE html>
<html lang="fr">
<head>
      <title>Traphouse : Boutique</title>
<!--commande php pour inclure le header-->
        <?php
include('header.php');
?> 
 <section class="page-header"> <!--marque page du header-->
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="content">
            <h1 class="page-name">Cryptomonnaies</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                <li class="breadcrumb-item active" aria-current="page">Boutique</li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>


        <div class="col-md-12"> <!--on dispose les produits-->
          <div class="row"> <!--en ligne de 4 produits-->
            <div class="col-md-3"> <!--produit 1-->
              <div class="product-item">
                <div class="product-thumb">
                  <span class="bage">Nouveauté</span>
                  <img class="img-responsive" src="images/magi.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="produit.php">Magi </a></h4>
                  <p class="price">$12.30</p>
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/botcoin.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="produit.php">Botcoin</a></h4>
                  <p class="price">$1340.02</p>
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/tornado.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="produit.php">Tornado</a></h4>
                  <p class="price">$657.21</p>
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/venom.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="produit.php">Venom</a></h4>
                  <p class="price">$98.54</p>
                </div>
              </div>
            </div>

           

            <div class="col-md-3">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/gury.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="produit.php">Gury</a></h4>
                  <p class="price">$73.21</p>
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/harch.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="produit.php">Harch</a></h4>
                  <p class="price">$142.56</p>
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/maki.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="produit.php">Maki</a></h4>
                  <p class="price">$23.90</p>
                </div>
              </div>
            </div>
			 <div class="col-md-3">
						  <div class="product-item">
							<div class="product-thumb">
							  <span class="bage">Nouveauté</span>
							  <img class="img-responsive" src="images/plural.png" alt="product-img">
							  <div class="preview-meta">
								<ul>
								  <li>
									<a href="produit.php"><i class="fa fa-search"></i></a>
								  </li>
								  <li>
									<a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
								  </li>
								</ul>
							  </div>
							</div>
							<div class="product-content">
							  <h4><a href="produit.php">Plural</a></h4>
							  <p class="price">$12.45</p>
							</div>
						  </div>
						</div>

            <div class="col-md-3">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/girco.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="produit.php">Girco</a></h4>
                  <p class="price">$54.93</p>
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="product-item">
                <div class="product-thumb">
                  <img class="img-responsive" src="images/cista.png" alt="product-img">
                  <div class="preview-meta">
                    <ul>
                      <li>
                        <a href="produit.php"><i class="fa fa-search"></i></a>
                      </li>
                      <li>
                        <a href="commande.php"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                    </ul>
                  </div>
                </div>
            
                <div class="product-content">
                  <h4><a href="produit.php">Cista</a></h4>
                  <p class="price">$32.06</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<!--commande php pour inclure le footer-->
  <?php
include('footer.php');
?> 

</body>
</html>
