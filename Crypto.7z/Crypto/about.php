<!DOCTYPE html>
<html lang="fr">
<head>
      <title>Traphouse : Renseignements</title>
<!--commande php pour inclure le header-->
        <?php
include('header.php');
?> 
 
 <section class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="content">
            <h1 class="page-name">À propos de nous</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active" aria-current="page">Renseignements</li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section>
           <div id="main_slider" class="section carousel slide banner-main" data-ride="carousel">
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <div class="container">
                     <div class="row marginii">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                           <div class="carousel-sporrt_text ">
                              <h1 class="sporrt_text">Qui a créé <strong class="black">Traphouse ?</strong></h1>

                                  <p class="lorem_text">Créé en 2018, notre boutique vous permet d’acheter et de vendre du Bitcoin et autres crypto-actifs, et ce de façon simple et rapide.</p>
                                  <p class="lorem_text">Nous avons pour vocation d'être un partenaire de confiance et à faciliter l’accès au marché des cryptomonnaies, s’adressant aussi bien aux particuliers qu’aux professionnels souhaitant acquérir des crypto-actifs.</p>
                                  <p class="lorem_text">Traphouse a vu le jour grâce à l'expertise et au savoir-faire de deux hommes, Quentin Bosseboeuf et Ruben Kabanga Muya. Leurs idées et leur passion pour la cryptomonnaie les ont menés à développer et faire émerger la plateforme.</p>
                                  <h1 class="sporrt_text">Nos <strong class="black">coordonnées</strong> </h1>
                                  <p class="lorem_text">Adresse du de notre siège social : </p>      
                                  <p class="lorem_text">1 PL DE LA CHENAIE - 94470 BOISSY-SAINT-LEGER</p>    
                                  <p class="lorem_text">Nous contacter : 09 82 73 22 33   <i class="fa fa-phone"></i></p>                                    
                                                                    
                                 <a class="btn btn-lg btn-primary" href="mailto:traphouse@yopmail.com" role="button"><i class="fa fa-envelope"></i>  Contact</a>
                           </div>
                        </div>
                        
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                           <div class="img-box">
                              <figure><img src="images/kekra.jpg" style="max-width: 100%; border: 15px solid #fff;"/></figure>
                              
                           </div>
                        </div>
                     </div>
                  </div>
               </div>

  </section>

<!--commande php pour inclure le footer-->
        <?php
include('footer.php');
?> 