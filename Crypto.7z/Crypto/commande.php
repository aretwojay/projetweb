<?php
include("header.php");
?>

    
  <section class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="content">
            <h1 class="page-name">Votre commande</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                <li class="breadcrumb-item active" aria-current="page">Panier</li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <section class="login section">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
            
        <p class="heading-text">Nécessite d'être inscrit(e).</p>
        <br>
        <form name="inscription" method="post" action="clients.php">
        <p>Produit(s) disponible(s):
        <select name="cryptos">
            <OPTION value='Botcoin'>Botcoin</OPTION>
            <OPTION value='Maki'>Maki</OPTION>
            <OPTION value='Tornado'>Tornado</OPTION>
            <OPTION value='Plural'>Plural</OPTION>
            <OPTION value='Venom'>Venom</OPTION>
            <OPTION value='Gury'>Gury</OPTION>
            <OPTION value='Harch'>Harch</OPTION>
            <OPTION value='Girco'>Girco</OPTION>
            <OPTION value='Cista'>Cista</OPTION>
            <OPTION value='Magi'>Magi</OPTION>
        </select></p>
                    <div class="form-group row">
              <label class="col-sm-3 col-form-label">E-mail <span class="req">*</span></label>
              <div class="col-sm-9">
                <input type="text" placeholder="Votre e-mail" class="form-control" name="emailclient">
              </div>
            </div>
                        <div class="form-group row">
              <label class="col-sm-3 col-form-label">Pour combien de dollars en voulez vous ? <span class="req">*</span></label>
              <div class="col-sm-9">
                <input type="text" placeholder="Votre budget" class="form-control" name="prix">
              </div>
            <input type="submit" class="btn btn-main float-right" name="valider"  value="SOUMETTRE">
        </form>
        </div>
      </div>
    </div>
  </section>
        
        
            <?php
if (isset($_POST['valider'])) {
    $email = $_POST['emailclient'];
    $prix  = $_POST['prixtotal'];
    $pwd   = $_POST['passwordclient'];
    
    //On se connecte
    connectMaBase();
    $sql = 'INSERT IGNORE INTO commande VALUES
    ("","' . $email . '","' . $pwd . '","' . $prixtotal . '");';
    mysql_query($sql) or die('ERREUR SQL ! <br>' . $sql . '<br>' . mysql_error());
    mysql_close();
    connectMaBase();
    //On prépare la requête SQL qui récupère les champs
    $sql = 'SELECT MAX(idcommande) FROM CLIENTS;';
    /* On lance la requête (mysql_query) 
    et on impose un message d'erreur si la requête ne passe pas (or die) */
    $req = mysql_query($sql) or die('Erreur SQL !<br />' . $sql . '<br />' . mysql_error());
    //boucle qui organise $req en tableau associatif $date['champ']
    //On scanne le résultat et on construit chaque option avec
    echo '<section>';
    echo "<p> Votre demande est en cours de traitement ";
    echo $data['idcommande'];
    echo "</p>";
    echo '</section>';
    //On libère mysql de cette première requête, mais on garde la variable PHP $data accessible
    mysql_free_result($req);
    //On ferme 
    mysql_close();
}
?>
<?php
	include('footer.php');
?> 
</body>