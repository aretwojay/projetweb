<?php
include("fonctions.php");
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cryptos : Accueil</title>
	<link rel="stylesheet" href="css/style.css.css">
</head>
<body>
	<section class="top-page">
		<header>
			<img src="images/logo2.png" alt="logo du site">
			<nav class="ENTETTE">
				<li>Accueil</li>
				<li>Boutique</li>
				<li>S'identifier</li>
			</nav>
		</header>
		<div class="landing-page">
			<h1 class="slogan">La boutique n°1 sur la cryptomonnaie</h1>
		</div>
	</section>
	<h1 align=center>S'inscrire</h1><br>
	<p class="lien"><a href="index.php">RETOUR</a></p>
	<h2 class="titre">Mes coordonnées </h2>
	<br>
	<form name="inscription" method="post" action="clients.php">
		Votre nom :<input type="text" name="nomclient"><br>
		Votre prénom :<input type="text" name="prenomclient"><br>
		Votre adresse email :<input type="email" name="emailclient"><br>
		Votre Pseudo :<input type="text" name="pseudoclient"><br>
		Choississez un mot de passe :<input type="password" name="passwordclient"><br>
		<input type="submit" name="valider" value="SOUMETTRE">
	</form>
	<?php
	if (isset ($_POST['valider'])) {
	$nom=$_POST['nomclient'];
	$prenom=$_POST['prenomclient'];
	$email=$_POST['emailclient'];
	$pseudo=$_POST['pseudoclient'];
	$pwd=$_POST['passwordclient'];

	//On se connecte
	connectMaBase();
	$sql = 'INSERT INTO CLIENTS VALUES
	("","'.$nom.'","'.$prenom.'","'.$email.'","'.$pseudo.'","'.$pwd.'");';
	mysql_query($sql) or die('ERREUR SQL ! <br>'.$sql.'<br>'.mysql_error());
	mysql_close();
	connectMaBase();
	//On prépare la requête SQL qui récupère les champs
	$sql = 'SELECT MAX(idclient) FROM CLIENTS;';
	/* On lance la requête (mysql_query) 
	et on impose un message d'erreur si la requête ne passe pas (or die) */ 
	$req = mysql_query($sql) or die('Erreur SQL !<br />'.$sql.'<br />'.mysql_error());
	//boucle qui organise $req en tableau associatif $date['champ']
	//On scanne le résultat et on construit chaque option avec
	echo '<section>';
	echo "<p>Vous etes maintenant inscrit ! ";
	echo "</p>";
	echo '</section>';
	//On libère mysql de cette première requête, mais on garde la variable PHP $data accessible
	mysql_free_result ($req); 
	//On ferme 
	mysql_close();}
	?>
</body>