<?php
include("fonctions.php");
?> 


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Traphouse : Votre compte</title>
	<link rel="stylesheet" href="css/style.css.css">
<!-- basic -->
    <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/logo3.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!-- owl stylesheets --> 
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesheet" href="css/owl.theme.default.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->	
</head>
<html lang="fr">
<body>
	<section class="top-page">
		<header>
			<img src="images/logo2.png" alt="logo du site">
			<nav class="ENTETTE">
				<li>Accueil</li>
				<li>Boutique</li>
				<li>S'identifier</li>
			</nav>
		</header>
		<div class="landing-page">
			<h1 class="slogan">La boutique n°1 sur la cryptomonnaie</h1>
		</div>
	</section>
	<h1 align=center>S'incrire</h1><br>
	<p class="lien"><a href="index.php">RETOUR</a></p>
	<h2 class="titre">Mes coordonnées </h2>
	<br>
	<form name="inscription" method="post" action="clients.php">
		<h2>Votre nom<input type="text" name="nomclient"><br>
			Votre prénom <input type="text" name="prenomclient"><br>
			Votre adresse email <input type="email" name="emailclient"><br>
			Votre Pseudo <input type="text" name="pseudoclient"><br>
			Choississez un mot de passe <input type="password" name="passwordclient"><br>
		</h2>
		<input type="submit" name="valider" value="SOUMETTRE">
	</form>
	<html lang="fr">
<body style="background-color:#AFEEEE;">
	
  <section class="top-header">
	 <div class="container">
      <div class="row">
        <div class="col-md-4 col-xs-12 col-sm-4">
          <div class="contact-number">
            <i class="fa fa-phone"></i>
            <span>09 82 73 22 33</span>
          </div>
        </div>     
          <!-- Site Logo -->
          <div class="logo">
            <a href="index.php"><img src="images/logo3.png" alt="#"></a>
          </div>
        </div>
		
		<div class="col-md-4 col-xs-12 col-sm-4">
          <ul class="top-menu list-inline">
            <li class="list-inline-item"><a href="cart.html"><i class="fa fa-shopping-cart"></i>Panier</a></li>
            <li class="list-inline-item"><a href="login.html"><i class="fa fa-sign-in"></i>Se connecter</a></li>
          </ul>
        </div>
      </div>
    </div>


	</section>
	  <section class="menu">
    <div class="container">
      <nav class="navbar navbar-expand-lg navbar-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Accueil</a> 
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Boutique
              </a>
              <div class="dropdown-menu full-width" aria-labelledby="navbarDropdown">
                <div class="row">
                  <div class="col-4">
                    <div class="dropdown-header">Cryptomonnaies</div>
                    <div class="dropdown-divider"></div>
                    <a href="shop.php">Botcoin</a>
                    <a href="shop.php">Tornado</a>
                    <a href="shop.php">Maki<a>
                    <a href="shop.php">Voir la liste</a>
                    <a href="shop.php"></a>
                  </div>
                  <div class="col-4">
                    <div class="dropdown-header">Outils</div>
                    <div class="dropdown-divider"></div>
                    <a href="shop.php">Cours des monnaies</a>
                    <a href="shop.php">Prédictions</a>
                    <a href="shop.php"></a>
                    <a href="shop.php"></a>
                    <a href="shop.php"></a>
                  </div>
                </div>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Renseignements
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="about.php">À propos de nous</a>
                <a class="dropdown-item" href="#">Contact</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </section>

	
	
  <section class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="content">
            <h1 class="page-name">Votre compte</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                <li class="breadcrumb-item active" aria-current="page">Compte</li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <section class="login section">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2 class="heading-text">Connexion</h2>
          <form id="inscription" method="post" action="clients.php">

            <div class="form-group row">
              <label class="col-sm-2 col-form-label">E-mail</label>
              <div class="col-sm-10">
                <input type="email" placeholder="Votre E-mail" class="form-control" name="emailclient" id="email">
              </div>
            </div>
            
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Mot de passe</label>
              <div class="col-sm-10">
                <input type="password" placeholder="Votre mot de passe" class="form-control" name="passwordclient" id="password">
              </div>
            </div>

            <input type="submit" class="btn btn-main" value="Connexion">
            <span class="forgot-password-text">Mot de passe oublié ?</span>
          </form>
        </div>

        <!-- <div class="col-md-6">
          <h2 class="heading-text">Reset Password</h2>
          <form id="contact-form" method="post" action="" role="form">

            <p>Please enter your email address below. You will receive a link to reset your password.</p>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Email <span class="req">*</span></label>
              <div class="col-sm-10">
                <input type="email" placeholder="Your Email" class="form-control" name="email" id="email">
              </div>
            </div>

            <input type="submit" class="btn btn-main" value="Login">
            <input type="submit" class="btn btn-transparent" value="Cancel">
          </form>
        </div> -->

        <div class="col-md-6">
          <h2 class="heading-text">S'inscrire</h2>
          <form id="contact-form" method="post" action="" role="form">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Prénom</label>
              <div class="col-sm-9">
                <input type="text" placeholder="Votre prénom" class="form-control" name="prenomclient" id="first-name">
              </div>
            </div>

            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Nom</label>
              <div class="col-sm-9">
                <input type="text" placeholder="Votre nom" class="form-control" name="nomclient" id="last-name">
              </div>
            </div>
			
			<div class="form-group row">
              <label class="col-sm-3 col-form-label">Pseudo <span class="req">*</span></label>
              <div class="col-sm-9">
                <input type="email" placeholder="Votre pseudo" class="form-control" name="pseudoclient" id="email">
              </div>
            </div>

            <div class="form-group row">
              <label class="col-sm-3 col-form-label">E-mail <span class="req">*</span></label>
              <div class="col-sm-9">
                <input type="email" placeholder="Votre E-mail" class="form-control" name="emailclient" id="email">
              </div>
            </div>
            
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Mot de passe<span class="req">*</span></label>
              <div class="col-sm-9">
                <input type="password" placeholder="Votre mot de passe" class="form-control" name="passwordclient" id="password">
              </div>
            </div>

            <input type="submit" class="btn btn-main float-right" value="Inscription">
          </form>
        </div>
      </div>
    </div>
  </section>
  	    <footer class="footer section text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <ul class="social-media">
            <li>
              <a href="">
                <i class="fa fa-instagram"></i>
              </a>
            </li>
            <li>
              <a href="">
                <i class="fa fa-twitter"></i>
              </a>
            </li>
            <li>
              <a href="">
                <i class="fa fa-pinterest"></i>
              </a>
            </li>
          </ul>
          <ul class="footer-menu">
            <li>
              <a href="">Contact</a>
            </li>
            <li>
              <a href="">Livraison</a>
            </li>
            <li>
              <a href="">Mentions légales</a>
            </li>
            <li>
              <a href="">Protection des données personnelles</a>
            </li>
          </ul>
          <p class="copyright-text">Copyright © 2021 All Rights Reserved. Traphouse </p>
        </div>
      </div>
    </div>
  </footer>

	
	<?php
	if (isset ($_POST['valider'])) {
	$nom=$_POST['nomclient'];
	$prenom=$_POST['prenomclient'];
	$email=$_POST['emailclient'];
	$pseudo=$_POST['pseudoclient'];
	$pwd=$_POST['passwordclient'];
	
	//On se connecte
	connectMaBase();
	$sql = 'INSERT INTO CLIENTS VALUES
	("","'.$nom.'","'.$prenom.'","'.$email.'","'.$pseudo.'","'.$pwd.'");';
	mysql_query($sql) or die('ERREUR SQL ! <br>'.$sql.'<br>'.mysql_error());
	mysql_close();
	echo'Vous etes maintenant inscrit';
	}
	?>
</body>